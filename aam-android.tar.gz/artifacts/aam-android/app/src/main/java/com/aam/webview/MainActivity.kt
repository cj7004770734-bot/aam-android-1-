package com.aam.webview

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {

    companion object {
        private const val BASE_URL =
            "https://cfd50fa9-d154-4367-bbf1-c9c3a58ba287-00-23iytw4hnyacq.pike.replit.dev/"
        private const val HOST =
            "cfd50fa9-d154-4367-bbf1-c9c3a58ba287-00-23iytw4hnyacq.pike.replit.dev"
    }

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var swipeRefresh: SwipeRefreshLayout

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        progressBar = findViewById(R.id.progressBar)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        webView = findViewById(R.id.webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            loadWithOverviewMode = true
            useWideViewPort = true
            allowFileAccess = false
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = false
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val url = request?.url ?: return false
                if (url.host == HOST) {
                    return false
                }
                return true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                progressBar.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                progressBar.visibility = View.GONE
                swipeRefresh.isRefreshing = false
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
            }
        }

        swipeRefresh.setOnRefreshListener {
            webView.reload()
        }

        val url = resolveDeepLinkUrl(intent)
        webView.loadUrl(url)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val url = resolveDeepLinkUrl(intent)
        webView.loadUrl(url)
    }

    private fun resolveDeepLinkUrl(intent: Intent?): String {
        val data: Uri = intent?.data ?: return BASE_URL

        if (data.scheme == "aam") {
            val host = data.host.orEmpty()
            val path = data.path.orEmpty()
            val fullPath = if (host.isNotEmpty() && path.isEmpty()) "/$host" else if (host.isNotEmpty()) "/$host$path" else path
            val query = data.query?.let { "?$it" }.orEmpty()
            val fragment = data.fragment?.let { "#$it" }.orEmpty()
            return BASE_URL.trimEnd('/') + fullPath + query + fragment
        }

        if (data.host == HOST) {
            return data.toString()
        }

        return BASE_URL
    }

    @Deprecated("Use onBackPressedDispatcher")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }
}
